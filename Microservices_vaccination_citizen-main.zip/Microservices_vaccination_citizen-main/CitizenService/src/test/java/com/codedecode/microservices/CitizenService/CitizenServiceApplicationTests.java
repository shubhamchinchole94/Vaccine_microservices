package com.codedecode.microservices.CitizenService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitizenServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
